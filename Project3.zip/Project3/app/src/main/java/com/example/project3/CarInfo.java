package com.example.project3;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;


public class CarInfo extends Fragment
{
    private HashMap<String,String> car_data;
    private ImageView imageview;
    private TextView disp_price;
    private TextView disp_desc;
    private TextView disp_model;
    private TextView disp_created;

    public CarInfo()
    {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if(bundle.getSerializable("Data")!=null)
        {
            car_data = (HashMap<String,String>)bundle.getSerializable("Data");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_car_info, container, false);
        imageview = root.findViewById(R.id.imageDisplay);
        disp_price = root.findViewById(R.id.priceDisplay);
        disp_created = root.findViewById(R.id.created_at_display);
        disp_desc = root.findViewById(R.id.descriptionDisplay);


        String image_url = car_data.get("image_url");
        String price = car_data.get("price");
        String make = car_data.get("vehicle_make");
        String description = car_data.get("vehicle_description");
        String model = car_data.get("model");
        String created_at = car_data.get("created_at");
        InputStream in = null;
        try {
             in = new URL(image_url).openStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Bitmap bmp = BitmapFactory.decodeStream(in);
        imageview.setImageBitmap(bmp);

        disp_price.setText("PRICE:"+price);
        disp_model.setText("Make-MODEL: "+make+" "+model);
        disp_desc.setText(description);
        disp_created.setText(created_at);



        return root;
    }
}