package com.example.project3;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class GetCarDescr extends AppCompatActivity
{
    private ImageView image_view;
    private TextView disp_price;
    private TextView disp_desc;
    private TextView disp_model;
    private TextView disp_created;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.car_descr);

        image_view = findViewById(R.id.display);
        disp_price = findViewById(R.id.price);
        disp_desc = findViewById(R.id.descript);
        disp_model = findViewById(R.id.model);
        disp_created = findViewById(R.id.created_at_display);


        Intent intent=getIntent();

        // Receiving the hashmap using getSerializableExtra method
        HashMap<String,String> car_list =(HashMap<String,String>)intent.getSerializableExtra("Data");



        String color = car_list.get("color");
        String created_at = car_list.get("created_at");
        String id = car_list.get("id");
        String image_url = car_list.get("image_url");
        String mileage = car_list.get("mileage");
        String model = car_list.get("model");
        String price = car_list.get("price");
        String veh_description = car_list.get("veh_description");
        String vehicle_make = car_list.get("vehicle_make");
        String vehicle_url = car_list.get("vehicle_url");
        String vin_number = car_list.get("vin_number");

        InputStream in = null;
        try {
            in = new URL(image_url).openStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Bitmap bmp = BitmapFactory.decodeStream(in);
        image_view.setImageBitmap(bmp);

        disp_price.setText("PRICE:" + price);
        disp_model.setText("Make/MODEL: "+ vehicle_make + " " + model);
        disp_desc.setText(veh_description);
        disp_created.setText("LAST UPDATED ON: " + created_at);
    }

}
