package com.example.project3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private String[] car_list;
    private Spinner spinner_make;
    private Spinner spinner_model;
    private String spinnerMakeID;
    private String spinnerMakeText;
    private String spinnerModelID;
    private String spinnerModelText;
    private ListView lv;
    private boolean mTwoPane;
    private ArrayList<HashMap<String,String>> car_info;
    private ArrayList<HashMap<String,String>> car_make;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (findViewById(R.id.container) != null)
        {
            mTwoPane = true;
        }
        else
        {
            mTwoPane = false;
        }

        spinner_make = findViewById(R.id.spinner_make);
        spinner_model = findViewById(R.id.spinner_model);
        lv = findViewById(R.id.customlistview);

        new GetCarMake().execute();
    }

    private class GetCarModel extends AsyncTask<Void, Void, Void>
    {
        private ArrayList<HashMap<String,String>> car_model;
        private String url = "https://thawing-beach-68207.herokuapp.com/carmodelmakes/" + spinnerMakeID;

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url);

            if (jsonStr != null)
            {
                try {
                    JSONArray car = new JSONArray(jsonStr);

                    for (int i = 0; i < car.length(); i++)
                    {
                        JSONObject c = car.getJSONObject(i);

                        String id = c.getString("id");
                        String model = c.getString("model");
                        String make = c.getString("vehicle_make_id");

                        HashMap<String,String> cm = new HashMap<>();
                        cm.put("id",id);
                        cm.put("model",model);
                        cm.put("vehicle_make_id",make);

                        car_model.add(cm);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result)
        {
            super.onPostExecute(result);

            String[] from = {"model"};
            int[] to = {R.id.spinner1text};
            // Initializing an adapter for spinner to store the data into the textview of the spinner
            final SpinnerAdapter adapter = new SimpleAdapter(MainActivity.this, car_model, R.layout.spinner_tv,from,to);
            spinner_model.setAdapter(adapter);
            spinner_model.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
            {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                    // Receiving the hashmap object from the selected item in the vehicle model spinner.
                    HashMap<String,String> v = (HashMap<String,String>)spinner_model.getSelectedItem();
                    try {
                        String str=spinner_model.getSelectedItem().toString();
                        spinnerModelID = v.get("model_id");
                        spinnerModelText = v.get("model");
                        new GetCarInfo().execute();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }

    private class GetCarMake extends AsyncTask<Void, Void, Void>
    {

        private String url = "https://thawing-beach-68207.herokuapp.com/carmakes";

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
            car_make = new ArrayList<>();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url);


            if (jsonStr != null)
            {
                try {
                    JSONObject jsonobject = new JSONObject(jsonStr);
                    // Receiving the JSON Array with the json array named "vehicle_list"
                    JSONArray cars = jsonobject.getJSONArray("");
                    for (int i = 0; i < cars.length(); i++)
                    {
                        JSONObject c = cars.getJSONObject(i);

                        String id = c.getString("id");
                        String make = c.getString("vehicle_make");

                        HashMap<String,String> cm = new HashMap<>();
                        cm.put("id",id);
                        cm.put("make",make);

                        car_make.add(cm);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void result)
        {
            super.onPostExecute(result);

            String[] from={"vehicle_make"};
            int[] to = {R.id.spinner1text};
            // Initializing an adapter for spinner to store the data into the textview of the spinner
            final SpinnerAdapter adapter = new SimpleAdapter(MainActivity.this, car_make, R.layout.spinner_tv,from,to);
            spinner_make.setAdapter(adapter);
            spinner_make.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener()
            {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
                {
                    HashMap<String,String> v = (HashMap<String,String>)spinner_make.getSelectedItem();
                    try {
                        // Storing the id and name of the the vehicle into string objects for future reference
                        spinnerMakeID = v.get("id");
                        spinnerMakeText = v.get("vehicle_make");

                        new GetCarModel().execute();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

        }
    }

    private class GetCarInfo extends AsyncTask<Void, Void, Void>
    {

        private String url = "https://thawing-beach-68207.herokuapp.com/cars/"+ spinnerMakeID +
            "/" + spinnerModelID + "/92603";

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {
            HttpHandler sh = new HttpHandler();
            String jsonStr = sh.makeServiceCall(url);

            if (jsonStr != null)
            {
                try {
                    JSONArray car = new JSONArray(jsonStr);

                    for (int i = 0; i < car.length(); i++)
                    {
                        JSONObject c = car.getJSONObject(i);

                        String id = c.getString("id");
                        String color_id = c.getString("color_id");
                        String content_local_url = c.getString("content_local_url");
                        String content_url = c.getString("content_url");
                        String created_at = c.getString("created_at");
                        String currency_id = c.getString("currency_id");
                        String image_local_url = c.getString("image_local_url");
                        String image_url = c.getString("image_url");
                        String is_active = c.getString("is_active");
                        String mileage = c.getString("mileage");
                        String onlinecardealer_id = c.getString("onlinecardealer_id");
                        String price = c.getString("price");
                        String seller_address = c.getString("seller_address");
                        String seller_address_locality = c.getString("seller_address_locality");
                        String seller_address_region = c.getString("seller_address_locality");
                        String seller_name = c.getString("seller_name");
                        String seller_telnumber = c.getString("seller_telnumber");
                        String updated_at = c.getString("updated_at");
                        String veh_description = c.getString("veh_description");
                        String vehicle_make_id = c.getString("vehicle_make_id");
                        String vehicle_model_id = c.getString("vehicle_model_id");
                        String vehicle_url = c.getString("vehicle_url");
                        String vin_number = c.getString("vin_number");
                        String zipcode_id = c.getString("zipcode_id");

                        HashMap<String,String> ci = new HashMap<>();
                        ci.put("id", id);
                        ci.put("color_id", color_id);
                        ci.put("content_local_url", content_local_url);
                        ci.put("content_url", content_url);
                        ci.put("created_at", created_at);
                        ci.put("currency_id", currency_id);
                        ci.put("image_local_url", image_local_url);
                        ci.put("image_url", image_url);
                        ci.put("is_active", is_active);
                        ci.put("mileage", mileage);
                        ci.put("onlinecardealer_id", onlinecardealer_id);
                        ci.put("price", price);
                        ci.put("seller_address", seller_address);
                        ci.put("seller_address_locality", seller_address_locality);
                        ci.put("seller_address_region", seller_address_region);
                        ci.put("seller_name", seller_name);
                        ci.put("seller_telnumber", seller_telnumber);
                        ci.put("updated_at", updated_at);
                        ci.put("veh_description", veh_description);
                        ci.put("vehicle_make_id", vehicle_make_id);
                        ci.put("vehicle_model_id", vehicle_model_id);
                        ci.put("vehicle_url", vehicle_url);
                        ci.put("vin_number", vin_number);
                        ci.put("zipcode_id", zipcode_id);
                        car_info.add(ci);
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void result)
        {
            super.onPostExecute(result);

            car_list = new String[car_info.size()];
            HashMap<String,String> hash;
            for(int i=0;i<car_info.size();i++)
            {
                hash = (HashMap<String,String>)car_info.get(i);
                car_list[i] = hash.get("vehicle_make") + " "+ hash.get("model")+" Price: "+ hash.get("price");
            }
            CarAdapter carAdap = new CarAdapter();
            lv.setAdapter(carAdap);
            lv.setOnItemClickListener(new AdapterView.OnItemClickListener(){
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                {
                    HashMap<String,String> car = (HashMap<String,String>)lv.getAdapter().getItem(position);
                    String str = car.get("price");



                    if(mTwoPane != true)
                    {
                        Intent intent = new Intent(getApplicationContext(),GetCarDescr.class);
                        intent.putExtra("Data",car);
                        startActivity(intent);
                    }
                    else
                    {
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("Data",car);
                        CarInfo carInfo = new CarInfo();
                        carInfo.setArguments(bundle);
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,carInfo).commit();
                    }

                }
            });
        }
    }

    private class CarAdapter extends BaseAdapter
    {
        @Override
        public View getView(int position, View convertView, ViewGroup parent)
        {
            View view = getLayoutInflater().inflate(R.layout.list_view,null);
            TextView tv =view.findViewById(R.id.tv);
            tv.setText(car_list[position]);
            return view;
        }

        @Override
        public int getCount() {
            return car_list.length;
        }

        @Override
        public Object getItem(int position)
        {
            return car_info.get(position);
        }

        @Override
        public long getItemId(int position)
        {
            return 0;
        }

    }
}
