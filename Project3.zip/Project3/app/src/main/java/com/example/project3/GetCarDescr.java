package com.example.project3;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class GetCarDescr extends AppCompatActivity
{

    private String url;
    private ImageView imageview;
    private TextView disp_price;
    private TextView disp_desc;
    private TextView disp_model;
    private TextView disp_created;



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.car_descr);

        imageview = findViewById(R.id.display);
        disp_price = findViewById(R.id.price);
        disp_desc = findViewById(R.id.descript);
        disp_model = findViewById(R.id.model);
        disp_created = findViewById(R.id.created_at_display);
        HttpHandler sh = new HttpHandler();
        String jsonStr = sh.makeServiceCall(url);

        if (jsonStr != null) {
            try {
                JSONObject jsonObj = new JSONObject(jsonStr);
                JSONArray c = jsonObj.getJSONArray("lists");

                for (int i = 0; i < c.length(); i++) {
                    JSONObject d = c.getJSONObject(i);

                    String color = d.getString("color");
                    String created_at = d.getString("created_at");
                    String id = d.getString("id");
                    String image_url = d.getString("image_url");
                    String mileage = d.getString("mileage");
                    String model = d.getString("model");
                    String price = d.getString("price");
                    String veh_description = d.getString("veh_description");
                    String vehicle_make = d.getString("vehicle_make");
                    String vehicle_url = d.getString("vehicle_url");
                    String vin_number = d.getString("vin_number");

                    InputStream in = null;
                    try {
                        in = new URL(image_url).openStream();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    Bitmap bmp = BitmapFactory.decodeStream(in);
                    imageview.setImageBitmap(bmp);

                    disp_price.setText("PRICE:"+price);
                    disp_model.setText("Make-MODEL: "+vehicle_make+" "+model);
                    disp_desc.setText(veh_description);
                    disp_created.setText("LAST UPDATED ON: "+created_at);


                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
